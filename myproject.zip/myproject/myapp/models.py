from django.db import models

# Create your models here.
class Student(models.Model):
    roll=models.IntegerField()
    stud_name=models.CharField(max_length=100)
    stud_address=models.CharField(max_length=100)
    stud_contact=models.IntegerField()
    stud_email=models.EmailField()
    stud_password=models.CharField(max_length=100)

class Cetegory(models.Model):
    title=models.CharField(max_length=100)
    desc=models.TextField()

    def __str__(self):
        return self.title

        

class Product(models.Model):
    P_name=models.CharField(max_length=100)
    P_description=models.CharField(max_length=100)
    P_price=models.IntegerField()
    P_quantity=models.IntegerField()
    prod_img=models.ImageField(upload_to='images/')
    uploaded_by=models.CharField(max_length=100)
    uploaded_date=models.DateTimeField(auto_now_add=True)
    cat=models.ForeignKey(Cetegory,on_delete=models.CASCADE)

