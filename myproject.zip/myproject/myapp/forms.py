from django import forms
from .models import Student,Product
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm

#First Way to create form
# class StudentForm(forms.Form):
#     student_name=forms.CharField(max_length=100)
#     student_email=forms.EmailField()
#     student_contact=forms.IntegerField()

class StudentForm(forms.ModelForm):
    class Meta:
        model=Student
        fields=['roll','stud_name','stud_address','stud_contact','stud_email','stud_password']
        widgets={'roll':forms.NumberInput(attrs={'class':'form-control'}),
                 'stud_name':forms.TextInput(attrs={'class':'form-control'}),
                 'stud_address':forms.TextInput(attrs={'class':'form-control'}),
                 'stud_contact':forms.NumberInput(attrs={'class':'form-control'}),
                 'stud_email':forms.EmailInput(attrs={'class':'form-control'}),
                 'stud_password':forms.PasswordInput(attrs={'class':'form-control'}),
        
       
         }

#Fisrt way        
class RegisterForm(UserCreationForm):
    password1=forms.CharField(label='Enter Password',widget=forms.PasswordInput(attrs={'class':'form-control'}))
    password2=forms.CharField(label='Enter Password',widget=forms.PasswordInput(attrs={'class':'form-control'}))
    email=forms.EmailField(label='Enter Email',widget=forms.EmailInput(attrs={'class':'form-control'}))

    class Meta:
        model=User
        fields=['username','first_name','last_name','email','password1']      

#Second way
        labels={
        'username':'Enter Username',
        'first_name':'Enter First Name',
        'last_name':'Enter Last Name'
        
    }    
        widgets={
        'username':forms.TextInput(attrs={'class':'form-control'}),
        'first_name':forms.TextInput(attrs={'class':'form-control'}),
        'last_name':forms.TextInput(attrs={'class':'form-control'})
    }

class LoginForm(AuthenticationForm):
    username=forms.CharField(label='Enter Username',widget=forms.TextInput(attrs={'class':'form-control'}))
    password=forms.CharField(label='Enter Password',widget=forms.PasswordInput(attrs={'class':'form-control'}))

    class Meta:
        model=User
        fields=['username','password']

      
class ProductForm(forms.ModelForm):
    class Meta:
        model=Product
        fields=['P_name','P_description','P_price','P_quantity','prod_img','cat']
        labels={
        'P_name':'Enter Product name',
        'P_description':'Enter Description',
        'P_price':'Enter Product Price',
        'P_quantity':'Enter Quantity',
        'cat':'category',
    }    
        widgets={'P_name':forms.TextInput(attrs={'class':'form-control'}),
                'P_description':forms.TextInput(attrs={'class':'form-control'}),
                'P_price':forms.NumberInput(attrs={'class':'form-control'}),
                'P_quantity':forms.NumberInput(attrs={'class':'form-control'}),
                'prod_img':forms.FileInput(attrs={'class':'form-control'}),
                'cat':forms.Select(attrs={'class':'form-control'}),
                }
        