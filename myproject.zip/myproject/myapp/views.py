from django.shortcuts import render,HttpResponse,redirect
#from .forms import StudentForm
from django.views import View
from django.contrib.auth.decorators import login_required
from .models import Product,Cetegory
from .forms import ProductForm
from django.contrib import messages
from .forms import RegisterForm,LoginForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate,login,logout
import datetime
# Create your views here.
#def home(request):
#    return HttpResponse("<h2>Hello</h2>")

#To render html page
# def home(request):
#     return render(request,'home.html')
    
def home(request):
    # context={'Name':'Nehahsdjfdkfjkgdfj','Marks':80,'list1':[1,2,3,4,5]}
    pro=Product.objects.all()  
    category1=Cetegory.objects.all()
    return render(request,'home.html',context={'category':category1,'pro':pro})    
        

def register(request):
    if request.method=="POST":
        fm=RegisterForm(request.POST)
        if fm.is_valid():   
            fm.save()
            return render(request,'home.html')

    else:
        fm=RegisterForm()
    return render(request,'register.html',context={'forms':fm})    


# class base view
class user_login(View):
    def get(self,request):
        fm=LoginForm()
        

        return render(request,'user_login.html',context={'form':fm}) 

    def post(self,request):
        uname=request.POST['username']
        upass=request.POST['password']
        user=authenticate(request,username=uname,password=upass)
        if user is not None:
            login(request,user)
            # request.session['username']=uname
            # messages.success(request,f'successfully {uname}LOGGEDIN')
            # response=render(request,'home.html',{'username':uname})
            # response.set_cookie('username',datetime.datetime.now())
            # return response
            messages.warning(request,f'  successfully {uname}LOGGEDIN')
            return redirect("home")
        else:
            messages.warning(request,f' not successfully {uname}LOGGEDIN')


# def user_login(request):
#     if request.method=='POST':
#         fm=LoginForm(request.POST)
#         uname=request.POST['username']
#         upass=request.POST['password']
#         user=authenticate(request,username=uname,password=upass)
#         if user is not None:
#             login(request,user)
#             return render (request,'home.html')
        
#     else:
#         fm=LoginForm()
#     return render(request,'user_login.html',context={'form':fm}) 
    

@login_required(login_url='user_login')
def Product_add(request):
    pro=Product.objects.all() 
    if request.method=="POST":
        fm=ProductForm(request.POST,request.FILES)
        if fm.is_valid():
            task=fm.save(commit=False)
            task.uploaded_by=request.user
            task.save()
            return render(request,'product.html',{'forms':fm,'pro':pro})
    else:        
        fm=ProductForm()
    return render(request,'product.html',{'forms':fm,'pro':pro})


def cat_view(request,id):
    category1=Cetegory.objects.all()
    pro=Product.objects.filter(cat=id)
    return render(request,'home.html',context={'category':category1,'pro':pro})

def show_view(request,id):
    pro=Product.objects.filter(id=id)
    return render(request,'showproduct.html',context={'pro':pro})


def search(request):
    if request.method=="POST":
        search_pro=request.POST['search']
        ser_product=Product.objects.filter(P_name__contains=search_pro)
        return render(request,'search.html',context={'pro':ser_product})

def update_product(request,id):
    pi=Product.objects.get(id=id)
    if request.method=="POST":
        fm=ProductForm(request.POST,instance=pi)
        if fm.is_valid():
            fm.save()
            return render(request,'home.html')
    else:
        fm=ProductForm(instance=pi)        
    return render (request,'update.html',{'forms':fm})

def delete_product(request,id):
    pi=Product.objects.get(id=id)
    pi.delete()
    return render(request,'home.html')


def sign_out(request):
    logout(request)
    return render(request,'home.html')

def about_us(request):
    return render(request,'about_us.html')

# def prod_update(request):
#     return render(request,'uupdate.html')



              
        
# def register(request):
#     if request.method=="POST":
#         fm=StudentForm(request.POST)
#         if fm.is_valid():
#             fm.save()
#     else:        
#         fm=StudentForm()
#     return render(request,'register.html',{'forms':fm})

# def register(request):
#     if request.method=="POST":
#         fm=UserCreationForm(request.POST)
#         if fm.is_valid():
#             fm.save()
#     else:
#         fm=UserCreationForm()
#     return render(request,'register.html',{'forms':fm})    


def prod_update(request):
    pro=Product.objects.all()
    return render(request,'product_info.html',context={'pro':pro})
    



