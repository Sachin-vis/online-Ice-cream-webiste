from django.contrib import admin

# Register your models here.
from .models import Student,Product,Cetegory
@admin.register(Student)
class studentadmin(admin.ModelAdmin):
    list_display=['roll','stud_name','stud_address','stud_contact','stud_email','stud_password']



@admin.register(Product)
class productadmin(admin.ModelAdmin):
    list_display=['id','P_name','P_description','P_price','P_quantity','uploaded_by']

@admin.register(Cetegory)
class categoryadmin(admin.ModelAdmin):
    list_display=['title','desc']

 