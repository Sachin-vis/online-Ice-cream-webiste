
from django.urls import path
from .import views
urlpatterns = [
    path('',views.home,name='home'),
    path('register/',views.register,name='register'),
    path('Login/',views.user_login.as_view(),name='user_login'),
    path('Add_product/',views.Product_add,name='Product'),
    path('cat/<int:id>/',views.cat_view,name='cat'),
    path('search/',views.search,name='search'),
    path('show/<int:id>/',views.show_view,name='show'),
    path('<int:id>/',views.update_product,name='update_data'),
    path('delete_product/<int:id>/',views.delete_product,name='delete_data'),
    path('about_us/',views.about_us,name='about_us'),
    path('Logout/',views.sign_out,name='sign_out'),
    path('update/',views.prod_update,name='update'),
    

    

]
